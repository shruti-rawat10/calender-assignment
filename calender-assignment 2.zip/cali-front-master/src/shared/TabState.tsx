import { withState } from "recompose";
export const TabState = withState("tabState", "changeTab", 1);
