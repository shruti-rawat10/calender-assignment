import styled from "styled-components";
import RouterButton from "./RouterButton";

export const NavLink = styled(RouterButton).attrs({
  color: "inherit"
})``;
