declare module "@hocs/debounce-handler" {
  const debounceHandler: (s: string, n: number) => typeof React.Component;
  export = debounceHandler;
}
